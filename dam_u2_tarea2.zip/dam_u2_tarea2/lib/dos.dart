import 'package:flutter/material.dart';

class Dos extends StatefulWidget {
  const Dos({Key? key}) : super(key: key);

  @override
  State<Dos> createState() => _DosState();
}

class _DosState extends State<Dos> {
  String _texto = '';

  TextEditingController _textoController = TextEditingController();

  void _actualizarTexto() {
    setState(() {
      _texto = _textoController.text;
      _textoController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          TextField(
            controller: _textoController,
            decoration: InputDecoration(
              hintText: 'Escribir texto aquí',
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _actualizarTexto,
            child: Text('Mostrar texto'),
          ),
          SizedBox(height: 20),
          Text(
            _texto,
            style: TextStyle(fontSize: 20),
          ),
        ],
      ),
    );
  }
}
