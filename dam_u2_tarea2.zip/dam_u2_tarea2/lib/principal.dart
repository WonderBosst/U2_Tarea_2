import 'package:dam_u2_tarea2/uno.dart';
import 'package:dam_u2_tarea2/dos.dart';
import 'package:dam_u2_tarea2/tres.dart';
import 'package:flutter/material.dart';

class Aplicacion9 extends StatefulWidget{

  @override
  State<StatefulWidget> createState() {
    return _Aplicacion9();
  }

}

class _Aplicacion9 extends State<Aplicacion9>{

  int _indice = 0;

  void _cambiarindice (int indice){
    setState(() {
      _indice = indice;
    });
  }

  final List<Widget> _paginas = [
    Uno(),
    Dos(),
    Tres(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: const Text("Tarea 2"),
        ),
      ),
      body: _paginas[_indice],
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.ad_units_rounded),
            label: "Mensaje de ",
            backgroundColor: Colors.grey,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_chart),
            label: "Dos",
            backgroundColor: Colors.grey,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle_rounded),
            label: "Tres",
            backgroundColor: Colors.grey,
          ),
        ],
        currentIndex: _indice,
        showUnselectedLabels: false,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white38,
        backgroundColor: Colors.red,
        onTap: _cambiarindice,
        iconSize: 30,
      ),
    );
  }

}