import 'dart:html';
import 'package:flutter/material.dart';

class Uno extends StatefulWidget {
  const Uno({Key? key}) : super(key: key);

  @override
  State<Uno> createState() => _UnoState();
}

class _UnoState extends State<Uno> {
  Stopwatch _stopwatch = Stopwatch();
  bool _isRunning = false;

  @override
  void dispose() {
    _stopwatch.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 50.0),
          child: Column(
            children: <Widget>[
              Text(
                'Cronometro',
                style: TextStyle(fontSize: 36.0, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 32.0),
              Text(
                '${_stopwatch.elapsed.inMinutes}:${(_stopwatch.elapsed.inSeconds % 60).toString().padLeft(2, '0')}',
                style: TextStyle(fontSize: 72.0),
              ),
              SizedBox(height: 32.0),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _isRunning = !_isRunning;
                    if (_isRunning) {
                      _stopwatch.start();
                    } else {
                      _stopwatch.stop();
                    }
                  });
                },
                child: Text(_isRunning ? 'Detener' : 'Iniciar'),
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(padding: EdgeInsets.all(5),
                        child: ElevatedButton(onPressed: (){
                          showDialog(context: context,
                              builder: (BuildContext context){
                                return AlertDialog(
                                  content: Text("Este cronometro una vez iniciado no se mostrara el reloj corriendo, lo que sucedera es que dandole nuevamente click al boton de !!!detener!!! este mostrara cuanto avanzo el cronometro desde que dio click a !!!iniciar!!!"),
                                  actions: [
                                    TextButton(onPressed: (){
                                      Navigator.of(context).pop();
                                    },
                                        child: Text("ok")
                                    )
                                  ],
                                );
                              });
                        }, child: Text("Mensaje !!importante!!!"))
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}