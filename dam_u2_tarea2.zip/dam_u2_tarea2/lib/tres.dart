import 'package:flutter/material.dart';

class Tres extends StatefulWidget {
  const Tres({Key? key}) : super(key: key);

  @override
  State<Tres> createState() => _TresState();
}

class _TresState extends State<Tres> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Numero de clicks:',
              ),
              Text(
                '$_counter',
                style: Theme.of(context).textTheme.headline4,
              ),
              ElevatedButton(
                onPressed: _incrementCounter,
                child: Text('Dame click'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}