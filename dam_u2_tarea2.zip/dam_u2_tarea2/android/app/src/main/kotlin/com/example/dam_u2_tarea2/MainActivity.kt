package com.example.dam_u2_tarea2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
